#' Module: Compile attributes
#'
#' @export
module_compile_Attributes <- function() {
  Rcpp::compileAttributes()

}
