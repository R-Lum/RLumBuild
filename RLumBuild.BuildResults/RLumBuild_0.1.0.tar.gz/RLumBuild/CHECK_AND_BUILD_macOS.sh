#!/bin/bash

R -q -e "RLumBuild::build_package()"